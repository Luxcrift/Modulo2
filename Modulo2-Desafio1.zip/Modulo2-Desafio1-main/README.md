# Modulo2-Desafio1
Desafio 1 del Modulo 2 del Bootcamp Educacion IT
En el siguiente enlace se puede ver la documentacion
https://docs.google.com/document/d/162OdJwIVnxhqsh5atMBMzXs0Z3C3QEtS9W4eiyDstYc/edit?usp=sharing
